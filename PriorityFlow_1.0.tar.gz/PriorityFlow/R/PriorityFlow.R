#' @details
#' prioirty flow does all these xyz things
#' the functions you might want si [D4TraverseB()]
#'  @keywords internal
#'  "_PACKAGE"
